/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.mphs.first.util;

import edu.mphs.first.interfaces.DigitalSideCarInterface;
import edu.wpi.first.wpilibj.AnalogChannel;
import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Relay;
import edu.wpi.first.wpilibj.Solenoid;
import edu.wpi.first.wpilibj.Timer;

/**
 *
 * @author Chris
 */
public class KickUtil {
        boolean m_timerRunning, m_primed, m_retryTimeRunning, m_kicked, m_ready;
        int m_potValue;
    public KickUtil()
    {
        m_ready = true;
        m_kicked = false;
        m_retryTimeRunning = false;
        m_timerRunning = false;
        m_primed = true;
    }

    public void manageKick(Joystick m_controlStick, Timer m_kickRetryTimer,
                            Timer m_kickReturnTimer,
                            DigitalInput m_retractedSwitch, DigitalInput m_kickedSwitch,
                            Solenoid m_primeSolenoid, Solenoid m_returnSolenoid,
                            Solenoid m_fireSolenoid,
                            Relay m_primer, AnalogChannel m_pot){
        if (!m_retryTimeRunning){
                m_kickRetryTimer.reset();
                m_retryTimeRunning = true;
            }
        if(m_retractedSwitch.get()){
            m_kickReturnTimer.reset();
            primeKickPNEU(m_returnSolenoid, m_primeSolenoid);
         if(m_controlStick.getRawButton(DigitalSideCarInterface.KICK_LATCH_RELEASE)){
        // Do not allow another key until the kick arm is retracted for at least 2 seconds!
            if ((DigitalSideCarInterface.KICK_WAIT) <= m_kickRetryTimer.get()){
                     m_fireSolenoid.set(true);
                     m_retryTimeRunning = false;
                }
         }
        }
        if(m_kickedSwitch.get()){
            resetPrimer(m_primer, m_pot);
            // Keep the m_timerRunning so that the Pot has time to unload the springs
            // before we attempt to return the kick arm to kick ready position
            if(m_timerRunning){
                if(m_kickReturnTimer.get() > DigitalSideCarInterface.RETRACT_WAIT){
                    returnKickArm(m_fireSolenoid, m_fireSolenoid, m_returnSolenoid);
                    m_kickReturnTimer.reset();
                    m_timerRunning  = false;
                }
            }else{
                m_kickReturnTimer.reset();
                m_timerRunning = true;
            }
        }
    }
    private boolean manageKick(int m_autonomousArea, Timer m_kickReturnTimer,
                            Solenoid m_primeSolenoid, Solenoid m_returnSolenoid,
                            Solenoid m_fireSolenoid,
                            Relay m_primer, AnalogChannel m_pot){
        if (m_ready){
            m_ready = false;
            if (!m_kicked){
                if(m_autonomousArea == 1){
                    m_fireSolenoid.set(true);
                    m_kicked = true;
                }
            }
            if(m_kicked){
                resetPrimer(m_primer, m_pot);
            // Keep the m_timerRunning so that the Pot has time to unload the springs
            // before we attempt to return the kick arm to kick ready position
                if(m_timerRunning){
                    if(m_kickReturnTimer.get() > DigitalSideCarInterface.RETRACT_WAIT){
                        returnKickArm(m_primeSolenoid, m_fireSolenoid, m_returnSolenoid);
                        m_timerRunning  = false;
                    }
                }else{
                    m_kickReturnTimer.reset();
                    m_timerRunning = true;
                }
            }
        }
        if (m_kicked && !m_timerRunning){
            return true;
        }else{
            return false;
        }
    }
    private void primeKickPNEU (Solenoid m_returnSolenoid, Solenoid m_primeSolenoid){
        // Public method because we need to call it from Team0514Robot for Autonomous Mode.
            m_returnSolenoid.set(false);
            m_primeSolenoid.set(true);
    }
    public void makeKickReady(Solenoid m_returnSolenoid, Solenoid m_primeSolenoid){
        m_ready = true;
        m_kicked = false;
        primeKickPNEU(m_returnSolenoid, m_primeSolenoid);
    }
    private void returnKickArm(Solenoid m_primeSolenoid, Solenoid m_fireSolenoid,
                               Solenoid m_returnSolenoid){
                    m_primeSolenoid.set(false);
                    m_fireSolenoid.set(false);
                    m_returnSolenoid.set(true);
    }

    public void managePrimer(AnalogChannel m_pot, Joystick m_controlStick,
                             Relay m_primer){
        m_potValue = m_pot.getAverageValue();
        if (m_controlStick.getRawButton(DigitalSideCarInterface.PRIME_1) || m_controlStick.getRawButton(DigitalSideCarInterface.PRIME_2))
        {
            if(m_controlStick.getRawButton(DigitalSideCarInterface.PRIME_1))
            {
                //m_primer.set(Relay.Value.kForward);
                loadHalfPrime(m_primer, m_pot);
            }
            else
            {
                //m_primer.set(Relay.Value.kReverse);
                loadFullPrime(m_primer, m_pot);
            }
        }
        else
        {
            m_primer.set(Relay.Value.kOff);
            resetPrimer(m_primer, m_pot);
        }
    }
    private void resetPrimer(Relay m_primer, AnalogChannel m_pot){
        //if (m_primed){
            if (m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_REST_UPPER_LIMIT)
                {
                    m_primer.set(Relay.Value.kReverse);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_REST_LOWER_LIMIT)
                {
                     m_primer.set(Relay.Value.kForward);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_REST_UPPER_LIMIT &&
                m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_REST_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kOff);
                    m_primed = false;
                }
            
         //}
    }
    private void loadHalfPrime(Relay m_primer, AnalogChannel m_pot){
        if (!m_primed){
            if (m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_HALF_UPPER_LIMIT)
                {
                    m_primer.set(Relay.Value.kReverse);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_HALF_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kForward);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_HALF_UPPER_LIMIT &&
                m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_HALF_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kOff);
                    m_primed = true;
                }
         }
    }
    private void loadFullPrime(Relay m_primer, AnalogChannel m_pot){
        if (!m_primed)
            {
            if (m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_FULL_UPPER_LIMIT)
                {
                    m_primer.set(Relay.Value.kReverse);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_FULL_LOWER_LIMIT)
                {
                    //m_primed = true;
                    m_primer.set(Relay.Value.kForward);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_FULL_UPPER_LIMIT &&
                m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_FULL_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kOff);
                    m_primed = true;
                }
         }

    }
    private boolean loadHalfPrime(int m_autonomousArea, Relay m_primer, AnalogChannel m_pot){
        if (!m_primed){
            if (m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_HALF_UPPER_LIMIT)
                {
                    m_primer.set(Relay.Value.kReverse);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_HALF_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kForward);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_HALF_UPPER_LIMIT &&
                m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_HALF_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kOff);
                    m_primed = true;
                }
         }
        if (m_primed){
            return true;
        }else{
            return false;
        }
    }
    private boolean loadFullPrime(int m_autonomousArea, Relay m_primer, AnalogChannel m_pot){
        int m_pot_diff = 0;
        int m_pot_prior = 0;

        if (!m_primed)
            {
            if (m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_FULL_UPPER_LIMIT)
                {
                    m_primer.set(Relay.Value.kReverse);
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_FULL_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kForward);
            // CAUTION!!
            // When the battery tires out the Primed Boolean may never make it to true!!!
            // Not really sure how to solve for this...
            // Routine to try and compensate for a tired battery 
            // When the prior Pot value = current Pot value the Pot is STOPPED
            // So set Primed to True and get out!
                    m_pot_diff = m_pot.getAverageValue() - m_pot_prior;
                    if (m_pot_diff == 0){
                        m_primed = true;
                    }else{
                        m_pot_prior = m_pot.getAverageValue();
                        m_primed = false;
                    }
                }
            if (m_pot.getAverageValue() <= DigitalSideCarInterface.PRIME_FULL_UPPER_LIMIT &&
                m_pot.getAverageValue() >= DigitalSideCarInterface.PRIME_FULL_LOWER_LIMIT)
                {
                    m_primer.set(Relay.Value.kOff);
                    m_primed = true;
                }
         }
        if (m_primed){
            return true;
        }else{
            return false;
        }
    }

    public boolean autoKick(int m_autonomousArea, Timer m_kickReturnTimer,
                            Solenoid m_primeSolenoid, Solenoid m_returnSolenoid,
                            Solenoid m_fireSolenoid,
                            Relay m_primer, AnalogChannel m_pot){

        boolean m_kickReset = false;
        boolean m_kickPrimed = false;

        switch (m_autonomousArea){

            case DigitalSideCarInterface.M_AUTONOMOUS_DEFENSE:
                if (!m_kickReset){
                    m_kickPrimed = loadFullPrime(m_autonomousArea, m_primer, m_pot);
                }
                if (m_kickPrimed){
                    m_kickReset = manageKick(m_autonomousArea, 
                            m_kickReturnTimer,
                            m_primeSolenoid, m_returnSolenoid,
                            m_fireSolenoid,
                            m_primer, m_pot);
                }
            break;

            case DigitalSideCarInterface.M_AUTONOMOUS_MIDFIELD:

            break;

            case DigitalSideCarInterface.M_AUTONOMOUS_OFFENSE:

            break;
        }
        if (m_kickReset){
            return true;
        }else{
            return false;
        }
    }

}